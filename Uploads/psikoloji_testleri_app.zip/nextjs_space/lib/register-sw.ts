
'use client'

export function registerServiceWorker() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    window.addEventListener('load', async () => {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js')
        console.log('Service Worker registered successfully:', registration.scope)
        
        // Update check
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // New content available, notify user
                if (confirm('Yeni bir sürüm mevcut. Sayfayı yenileyip güncellemek ister misiniz?')) {
                  window.location.reload()
                }
              }
            })
          }
        })
      } catch (error) {
        console.log('Service Worker registration failed:', error)
      }
    })
  }
}

// PWA Install prompt
export function setupPWAInstall() {
  if (typeof window === 'undefined') return

  let deferredPrompt: any

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault()
    deferredPrompt = e
    
    // Show custom install button or banner
    const installBanner = document.createElement('div')
    installBanner.innerHTML = `
      <div style="
        position: fixed;
        bottom: 20px;
        left: 20px;
        right: 20px;
        background: #2563eb;
        color: white;
        padding: 16px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-family: system-ui, -apple-system, sans-serif;
      ">
        <div>
          <strong>Psikoloji Testleri</strong><br>
          <small>Ana ekrana eklemek ister misiniz?</small>
        </div>
        <div>
          <button id="install-btn" style="
            background: white;
            color: #2563eb;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            font-weight: 500;
            margin-right: 8px;
            cursor: pointer;
          ">Ekle</button>
          <button id="dismiss-btn" style="
            background: transparent;
            color: white;
            border: 1px solid white;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
          ">Hayır</button>
        </div>
      </div>
    `
    
    document.body.appendChild(installBanner)
    
    const installBtn = document.getElementById('install-btn')
    const dismissBtn = document.getElementById('dismiss-btn')
    
    installBtn?.addEventListener('click', async () => {
      deferredPrompt.prompt()
      const { outcome } = await deferredPrompt.userChoice
      console.log('PWA install outcome:', outcome)
      deferredPrompt = null
      installBanner.remove()
    })
    
    dismissBtn?.addEventListener('click', () => {
      installBanner.remove()
    })
  })
}

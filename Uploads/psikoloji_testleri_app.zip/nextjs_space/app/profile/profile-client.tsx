
'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { 
  User, 
  Mail, 
  Calendar, 
  FileText, 
  ArrowLeft,
  Clock,
  CheckCircle,
  Send
} from 'lucide-react'
import Link from 'next/link'
import { useToast } from '@/hooks/use-toast'

interface TestResult {
  id: string
  totalScore: number
  completedAt: string
  emailSent: boolean
  test: {
    testName: string
    testCode: string
  }
}

export default function ProfileClient() {
  const { data: session } = useSession() || {}
  const [testResults, setTestResults] = useState<TestResult[]>([])
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    fetchTestResults()
  }, [])

  const fetchTestResults = async () => {
    try {
      const response = await fetch('/api/test-results')
      if (response.ok) {
        const data = await response.json()
        setTestResults(data || [])
      }
    } catch (error) {
      console.error('Error fetching test results:', error)
    } finally {
      setLoading(false)
    }
  }

  const sendEmail = async (testResultId: string) => {
    try {
      const response = await fetch(`/api/test-results/${testResultId}/email`, {
        method: 'POST',
      })
      
      if (response.ok) {
        toast({
          title: 'Başarılı!',
          description: 'Test sonuçları e-posta adresinize gönderildi',
        })
        fetchTestResults() // Refresh to update emailSent status
      } else {
        throw new Error('Email gönderilemedi')
      }
    } catch (error) {
      toast({
        title: 'Hata',
        description: 'E-posta gönderilemedi. Lütfen tekrar deneyin.',
        variant: 'destructive',
      })
    }
  }

  const getTestCodeColor = (testCode: string) => {
    switch (testCode) {
      case 'MMPI':
        return 'bg-orange-100 text-orange-700'
      case 'SCL-90-R':
        return 'bg-blue-100 text-blue-700'
      case 'ODO':
        return 'bg-purple-100 text-purple-700'
      default:
        return 'bg-gray-100 text-gray-700'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <User className="h-16 w-16 text-blue-500 animate-pulse mx-auto mb-4" />
          <p className="text-gray-600">Profil yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button variant="ghost" className="flex items-center space-x-2">
              <ArrowLeft className="h-4 w-4" />
              <span>Ana Sayfaya Dön</span>
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Profilim</h1>
          <div className="w-24"></div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* User Info Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-1"
          >
            <Card className="bg-white/80 backdrop-blur-md border-0 shadow-xl">
              <CardHeader className="text-center">
                <Avatar className="h-24 w-24 mx-auto mb-4">
                  <AvatarFallback className="bg-blue-500 text-white text-2xl">
                    {session?.user?.firstName?.[0] || session?.user?.name?.[0] || 'K'}
                  </AvatarFallback>
                </Avatar>
                <CardTitle className="text-2xl text-gray-900">
                  {session?.user?.firstName} {session?.user?.lastName}
                </CardTitle>
                <CardDescription className="text-lg">
                  {session?.user?.email}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3 text-gray-600">
                  <Mail className="h-5 w-5" />
                  <span>{session?.user?.email}</span>
                </div>
                <div className="flex items-center space-x-3 text-gray-600">
                  <FileText className="h-5 w-5" />
                  <span>{testResults?.length || 0} tamamlanan test</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Test Results */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="bg-white/80 backdrop-blur-md border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Test Geçmişi</span>
                </CardTitle>
                <CardDescription>
                  Tamamladığınız testlerin sonuçları
                </CardDescription>
              </CardHeader>
              <CardContent>
                {testResults?.length === 0 ? (
                  <div className="text-center py-12">
                    <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 text-lg mb-2">Henüz test tamamlamadınız</p>
                    <p className="text-gray-400 mb-6">İlk testinizi çözün ve sonuçlarınızı burada görün</p>
                    <Link href="/">
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        Testlere Göz At
                      </Button>
                    </Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {testResults?.map?.((result, index) => (
                      <motion.div
                        key={result?.id || index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                        className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-3">
                            <Badge className={`${getTestCodeColor(result?.test?.testCode || '')}`}>
                              {result?.test?.testCode || 'TEST'}
                            </Badge>
                            <h3 className="font-semibold text-gray-900">
                              {result?.test?.testName || 'Test Adı Bulunamadı'}
                            </h3>
                          </div>
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        </div>

                        <div className="grid md:grid-cols-3 gap-4 mb-4">
                          <div className="text-center">
                            <p className="text-2xl font-bold text-blue-600">
                              {result?.totalScore || 0}
                            </p>
                            <p className="text-sm text-gray-600">Toplam Puan</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-gray-900 flex items-center justify-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              {new Date(result?.completedAt || '').toLocaleDateString('tr-TR')}
                            </p>
                            <p className="text-sm text-gray-600">Tamamlanma Tarihi</p>
                          </div>
                          <div className="text-center">
                            <p className="text-sm font-medium text-gray-900 flex items-center justify-center">
                              <Clock className="h-4 w-4 mr-1" />
                              {new Date(result?.completedAt || '').toLocaleTimeString('tr-TR', {
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                            <p className="text-sm text-gray-600">Tamamlanma Saati</p>
                          </div>
                        </div>

                        <div className="flex justify-end">
                          <Button
                            onClick={() => sendEmail(result?.id || '')}
                            variant={result?.emailSent ? "outline" : "default"}
                            size="sm"
                            className="flex items-center space-x-2"
                          >
                            <Send className="h-4 w-4" />
                            <span>
                              {result?.emailSent ? 'E-posta Gönderildi' : 'E-posta ile Gönder'}
                            </span>
                          </Button>
                        </div>
                      </motion.div>
                    )) || []}
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  )
}


'use client'

import { SessionProvider as NextAuthProvider } from 'next-auth/react'
import { ReactNode, useEffect, useState } from 'react'

interface Props {
  children: ReactNode
}

export const SessionProvider = ({ children }: Props) => {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  if (!isMounted) {
    return <>{children}</>
  }

  return <NextAuthProvider>{children}</NextAuthProvider>
}

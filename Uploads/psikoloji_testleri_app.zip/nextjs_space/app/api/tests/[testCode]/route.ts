
export const dynamic = "force-dynamic"

import { NextRequest, NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'

const prisma = new PrismaClient()

export async function GET(request: NextRequest, { params }: { params: { testCode: string } }) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const test = await prisma.test.findUnique({
      where: { testCode: params?.testCode || '' },
    })

    if (!test) {
      return NextResponse.json({ error: 'Test bulunamadı' }, { status: 404 })
    }

    // Progress kontrol et
    const progress = await prisma.testProgress.findUnique({
      where: {
        userId_testId: {
          userId: session.user.id,
          testId: test.id,
        },
      },
    })

    return NextResponse.json({
      test,
      progress: progress || null,
    })
  } catch (error) {
    console.error('Test fetch error:', error)
    return NextResponse.json({ error: 'Test yüklenemedi' }, { status: 500 })
  }
}

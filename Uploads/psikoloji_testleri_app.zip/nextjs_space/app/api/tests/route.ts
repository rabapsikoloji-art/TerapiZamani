
export const dynamic = "force-dynamic"

import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET() {
  try {
    const tests = await prisma.test.findMany({
      select: {
        id: true,
        testCode: true,
        testName: true,
        description: true,
        totalQuestions: true,
        instructions: true,
        timeFrame: true,
      },
      orderBy: {
        createdAt: 'asc'
      }
    })

    return NextResponse.json(tests)
  } catch (error) {
    console.error('Tests fetch error:', error)
    return NextResponse.json({ error: 'Testler yüklenemedi' }, { status: 500 })
  }
}

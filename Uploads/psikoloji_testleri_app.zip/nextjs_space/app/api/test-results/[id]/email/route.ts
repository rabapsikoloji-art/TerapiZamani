
export const dynamic = "force-dynamic"

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const testResult = await prisma.testResult.findFirst({
      where: {
        id: params?.id || '',
        userId: session.user.id,
      },
      include: {
        test: true,
        user: true,
      },
    })

    if (!testResult) {
      return NextResponse.json({ error: 'Test sonucu bulunamadı' }, { status: 404 })
    }

    // Email simülasyonu (gerçek email servisi yok)
    console.log('EMAIL SIMULATION:')
    console.log('To:', session.user.email)
    console.log('Subject: Test Sonuçlarınız -', testResult?.test?.testName)
    console.log('Body:')
    console.log(`
Sayın ${session.user.firstName} ${session.user.lastName},

${testResult?.test?.testName} testinizin sonuçları:
- Test Kodu: ${testResult?.test?.testCode}
- Tamamlanma Tarihi: ${testResult?.completedAt?.toLocaleDateString('tr-TR')}
- Toplam Puan: ${testResult?.totalScore || 'Hesaplanmadı'}
- Cevaplar: ${Object.keys(testResult?.answers as any || {}).length} soru cevaplanmış

Detaylı sonuçlarınızı platformda görüntüleyebilirsiniz.

Saygılarımızla,
Psikoloji Testleri Ekibi
    `)

    // Email gönderildi olarak işaretle
    await prisma.testResult.update({
      where: { id: testResult.id },
      data: { emailSent: true },
    })

    return NextResponse.json({ 
      success: true, 
      message: 'Test sonuçları e-posta adresinize gönderildi' 
    })
  } catch (error) {
    console.error('Email send error:', error)
    return NextResponse.json({ error: 'E-posta gönderilemedi' }, { status: 500 })
  }
}


export const dynamic = "force-dynamic"

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { testId, answers, scores, totalScore } = await request.json()

    if (!testId || !answers) {
      return NextResponse.json({ error: 'Eksik bilgiler' }, { status: 400 })
    }

    // Test sonucunu kaydet
    const testResult = await prisma.testResult.create({
      data: {
        userId: session.user.id,
        testId: testId,
        answers: answers,
        scores: scores || {},
        totalScore: totalScore || null,
        isCompleted: true,
        completedAt: new Date(),
      },
    })

    // Test progress'i sil (tamamlandı)
    await prisma.testProgress.deleteMany({
      where: {
        userId: session.user.id,
        testId: testId,
      },
    })

    return NextResponse.json({ success: true, testResult })
  } catch (error) {
    console.error('Test result save error:', error)
    return NextResponse.json({ error: 'Test sonucu kaydedilemedi' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const testResults = await prisma.testResult.findMany({
      where: {
        userId: session.user.id,
        isCompleted: true,
      },
      include: {
        test: {
          select: {
            testName: true,
            testCode: true,
          },
        },
      },
      orderBy: {
        completedAt: 'desc',
      },
    })

    return NextResponse.json(testResults)
  } catch (error) {
    console.error('Test results fetch error:', error)
    return NextResponse.json({ error: 'Test sonuçları yüklenemedi' }, { status: 500 })
  }
}

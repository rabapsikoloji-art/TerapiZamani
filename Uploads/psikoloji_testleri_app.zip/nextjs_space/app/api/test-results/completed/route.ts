
export const dynamic = "force-dynamic"

import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const completedTests = await prisma.testResult.findMany({
      where: {
        userId: session.user.id,
        isCompleted: true
      },
      select: {
        testId: true
      }
    })

    const completedTestIds = completedTests?.map?.(result => result?.testId || '') || []

    return NextResponse.json({ completedTestIds })
  } catch (error) {
    console.error('Completed tests fetch error:', error)
    return NextResponse.json({ error: 'Tamamlanan testler yüklenemedi' }, { status: 500 })
  }
}

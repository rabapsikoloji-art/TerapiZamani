
export const dynamic = "force-dynamic"

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { testId, currentQuestion, answers } = await request.json()

    if (!testId || currentQuestion === undefined || !answers) {
      return NextResponse.json({ error: 'Eksik bilgiler' }, { status: 400 })
    }

    const progress = await prisma.testProgress.upsert({
      where: {
        userId_testId: {
          userId: session.user.id,
          testId: testId,
        },
      },
      update: {
        currentQuestion: currentQuestion,
        answers: answers,
      },
      create: {
        userId: session.user.id,
        testId: testId,
        currentQuestion: currentQuestion,
        answers: answers,
      },
    })

    return NextResponse.json({ success: true, progress })
  } catch (error) {
    console.error('Test progress save error:', error)
    return NextResponse.json({ error: 'İlerleme kaydedilemedi' }, { status: 500 })
  }
}

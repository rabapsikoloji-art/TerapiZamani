
import './globals.css'
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { SessionProvider } from './providers/session-provider'
import { ThemeProvider } from '@/components/theme-provider'
import { Toaster } from '@/components/ui/toaster'
import PWARegister from './pwa-register'

const inter = Inter({ subsets: ['latin'] })

export const dynamic = "force-dynamic"

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXTAUTH_URL || 'http://localhost:3000'),
  title: 'Psikoloji Testleri - Kapsamlı Psikolojik Değerlendirme Platformu',
  description: 'MMPI, SCL-90 ve Otomatik Düşünceler ölçekleri ile profesyonel psikolojik değerlendirme yapın. Güvenilir sonuçlar için bilimsel testler.',
  keywords: 'psikoloji testleri, MMPI, SCL-90, otomatik düşünceler, psikolojik değerlendirme, kişilik testi',
  authors: [{ name: 'Psikoloji Testleri' }],
  openGraph: {
    title: 'Psikoloji Testleri - Kapsamlı Psikolojik Değerlendirme',
    description: 'Profesyonel psikoloji testleri ile kendinizi değerlendirin',
    images: ['/og-image.png'],
    type: 'website',
  },
  icons: {
    icon: '/favicon.svg',
    shortcut: '/favicon.svg',
  },
  manifest: '/manifest.json',
  viewport: 'width=device-width, initial-scale=1',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="tr" suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem={false}
          disableTransitionOnChange
        >
          <SessionProvider>
            <PWARegister />
            {children}
            <Toaster />
          </SessionProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

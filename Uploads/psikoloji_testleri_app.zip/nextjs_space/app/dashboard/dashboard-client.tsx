
'use client'

import { motion } from 'framer-motion'
import { useSession, signOut } from 'next-auth/react'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Brain, FileText, BarChart3, User, LogOut, CheckCircle } from 'lucide-react'
import Link from 'next/link'

interface Test {
  id: string
  testCode: string
  testName: string
  description: string
  totalQuestions: number
  instructions?: string
  timeFrame?: string
}

export default function DashboardClient() {
  const { data: session } = useSession() || {}
  const [tests, setTests] = useState<Test[]>([])
  const [loading, setLoading] = useState(true)
  const [completedTests, setCompletedTests] = useState<string[]>([])

  useEffect(() => {
    fetchTests()
    fetchCompletedTests()
  }, [])

  const fetchTests = async () => {
    try {
      const response = await fetch('/api/tests')
      const data = await response.json()
      setTests(data)
    } catch (error) {
      console.error('Error fetching tests:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchCompletedTests = async () => {
    try {
      const response = await fetch('/api/test-results/completed')
      if (response.ok) {
        const data = await response.json()
        setCompletedTests(data.completedTestIds || [])
      }
    } catch (error) {
      console.error('Error fetching completed tests:', error)
    }
  }

  const getTestIcon = (testCode: string) => {
    switch (testCode) {
      case 'MMPI':
        return <Brain className="h-12 w-12 text-orange-500" />
      case 'SCL-90-R':
        return <BarChart3 className="h-12 w-12 text-blue-500" />
      case 'ODO':
        return <FileText className="h-12 w-12 text-purple-500" />
      default:
        return <Brain className="h-12 w-12 text-gray-500" />
    }
  }

  const getTestColor = (testCode: string) => {
    switch (testCode) {
      case 'MMPI':
        return 'from-orange-100 to-orange-200 border-orange-200'
      case 'SCL-90-R':
        return 'from-blue-100 to-blue-200 border-blue-200'
      case 'ODO':
        return 'from-purple-100 to-purple-200 border-purple-200'
      default:
        return 'from-gray-100 to-gray-200 border-gray-200'
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Brain className="h-16 w-16 text-blue-500 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Testler yükleniyor...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-blue-200">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Brain className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Psikoloji Testleri</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link href="/profile">
                <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">Profil</span>
                </Button>
              </Link>
              
              <div className="flex items-center space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-blue-500 text-white">
                    {session?.user?.firstName?.[0] || session?.user?.name?.[0] || 'K'}
                  </AvatarFallback>
                </Avatar>
                <div className="hidden sm:block">
                  <p className="text-sm font-medium text-gray-900">
                    {session?.user?.firstName} {session?.user?.lastName}
                  </p>
                  <p className="text-xs text-gray-500">{session?.user?.email}</p>
                </div>
              </div>
              
              <Button
                onClick={() => signOut({ callbackUrl: '/auth/login' })}
                variant="outline"
                size="sm"
                className="flex items-center space-x-2"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Çıkış</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Uzmanına ve bilgilerinizdeki psikoloji testleri ile kendizi test edin
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Psikolojik durumunızı değerlendirmek için bilimsel olarak kanıtlanmış testleri kullanın. 
            Tüm sonuçlarınız güvenle saklanır ve e-posta ile size gönderilir.
          </p>
        </motion.div>

        {/* Test Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tests?.map?.((test, index) => (
            <motion.div
              key={test?.id || `test-${index}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className={`h-full bg-gradient-to-br ${getTestColor(test?.testCode || '')} hover:shadow-lg transition-all duration-300 group cursor-pointer relative`}>
                {completedTests?.includes?.(test?.id || '') && (
                  <div className="absolute top-4 right-4 z-10">
                    <CheckCircle className="h-6 w-6 text-green-500 bg-white rounded-full" />
                  </div>
                )}
                
                <CardHeader className="text-center pb-4">
                  <div className="mb-4 flex justify-center group-hover:scale-110 transition-transform duration-300">
                    {getTestIcon(test?.testCode || '')}
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900 mb-2">
                    {test?.testName || 'Test Adı Bulunamadı'}
                  </CardTitle>
                  <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
                    <FileText className="h-4 w-4" />
                    <span>{test?.totalQuestions || 0} Soru</span>
                  </div>
                  {test?.timeFrame && (
                    <p className="text-xs text-gray-500 mt-1">{test.timeFrame}</p>
                  )}
                </CardHeader>
                
                <CardContent className="pt-0">
                  <CardDescription className="text-gray-700 mb-6 min-h-[80px] leading-relaxed">
                    {test?.description || 'Test açıklaması bulunamadı.'}
                  </CardDescription>
                  
                  <Link href={`/test/${test?.testCode || ''}`}>
                    <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-lg transition-colors">
                      {completedTests?.includes?.(test?.id || '') ? 'Tekrar Çöz' : 'Teste Başla'}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          )) || []}
        </div>

        {(!tests || tests.length === 0) && !loading && (
          <div className="text-center py-12">
            <Brain className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Henüz hiç test bulunamadı.</p>
          </div>
        )}
      </main>
    </div>
  )
}


'use client'

import { useEffect } from 'react'
import { registerServiceWorker, setupPWAInstall } from '@/lib/register-sw'

export default function PWARegister() {
  useEffect(() => {
    registerServiceWorker()
    setupPWAInstall()
  }, [])

  return null
}


'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import { 
  ArrowLeft, 
  ArrowRight, 
  Brain, 
  CheckCircle, 
  Home,
  Save,
  AlertTriangle
} from 'lucide-react'
import { useToast } from '@/hooks/use-toast'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import Link from 'next/link'

interface Question {
  id: number
  text: string
  options: Array<{
    value: number | string
    label: string
  }>
}

interface Test {
  id: string
  testCode: string
  testName: string
  description: string
  totalQuestions: number
  instructions?: string
  timeFrame?: string
  questions: Question[]
}

interface TestProgress {
  currentQuestion: number
  answers: Record<string, any>
  isCompleted: boolean
}

interface Props {
  testCode: string
}

export default function TestClient({ testCode }: Props) {
  const [test, setTest] = useState<Test | null>(null)
  const [progress, setProgress] = useState<TestProgress | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState(1)
  const [answers, setAnswers] = useState<Record<string, any>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showInstructions, setShowInstructions] = useState(true)
  const [isCompleted, setIsCompleted] = useState(false)
  const [testResult, setTestResult] = useState<any>(null)
  
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    fetchTestData()
  }, [testCode])

  const fetchTestData = async () => {
    try {
      const response = await fetch(`/api/tests/${testCode}`)
      if (!response.ok) {
        throw new Error('Test bulunamadı')
      }

      const data = await response.json()
      setTest(data?.test || null)
      
      if (data?.progress) {
        setProgress(data.progress)
        setCurrentQuestion(data?.progress?.currentQuestion || 1)
        setAnswers(data?.progress?.answers || {})
        setShowInstructions(false)
      }
    } catch (error) {
      console.error('Test fetch error:', error)
      toast({
        title: 'Hata',
        description: 'Test yüklenemedi',
        variant: 'destructive',
      })
      router.push('/')
    } finally {
      setLoading(false)
    }
  }

  const saveProgress = async () => {
    if (!test) return

    setSaving(true)
    try {
      await fetch('/api/test-progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          testId: test.id,
          currentQuestion,
          answers,
        }),
      })
    } catch (error) {
      console.error('Progress save error:', error)
    } finally {
      setSaving(false)
    }
  }

  const handleAnswer = (questionId: number, value: any) => {
    const newAnswers = { ...answers, [questionId]: value }
    setAnswers(newAnswers)
  }

  const nextQuestion = async () => {
    if (!test) return

    // İlerleme kaydet
    await saveProgress()

    if (currentQuestion < test.totalQuestions) {
      setCurrentQuestion(currentQuestion + 1)
    } else {
      // Test tamamlandı
      await completeTest()
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 1) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const completeTest = async () => {
    if (!test) return

    try {
      const scores = calculateScores()
      const totalScore = calculateTotalScore()

      const response = await fetch('/api/test-results', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          testId: test.id,
          answers,
          scores,
          totalScore,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setTestResult(data?.testResult)
        setIsCompleted(true)
        toast({
          title: 'Tebrikler!',
          description: 'Test başarıyla tamamlandı',
        })
      }
    } catch (error) {
      console.error('Test completion error:', error)
      toast({
        title: 'Hata',
        description: 'Test tamamlanamadı',
        variant: 'destructive',
      })
    }
  }

  const calculateScores = () => {
    if (!test) return {}
    
    // Her test için özel puanlama mantığı
    const scores: Record<string, number> = {}
    
    try {
      if (test.testCode === 'ODO') {
        // Otomatik Düşünceler Ölçeği puanlaması
        const scales = (test as any)?.scales || {}
        Object.keys(scales).forEach(scaleKey => {
          const scale = scales[scaleKey]
          if (scale?.questionIds) {
            let scaleScore = 0
            scale.questionIds.forEach((qId: number) => {
              const answer = answers[qId]
              if (typeof answer === 'number') {
                scaleScore += answer
              }
            })
            scores[scaleKey] = scaleScore
          }
        })
      } else {
        // Diğer testler için basit toplam
        let totalAnswered = 0
        Object.values(answers).forEach(answer => {
          if (typeof answer === 'number') {
            totalAnswered += answer
          }
        })
        scores['total'] = totalAnswered
      }
    } catch (error) {
      console.error('Score calculation error:', error)
    }

    return scores
  }

  const calculateTotalScore = () => {
    if (!test) return 0
    
    let total = 0
    Object.values(answers).forEach(answer => {
      if (typeof answer === 'number') {
        total += answer
      }
    })
    return total
  }

  const getCurrentQuestionData = () => {
    if (!test || !test.questions) return null
    return test.questions.find(q => q?.id === currentQuestion) || null
  }

  const progressPercentage = test ? ((currentQuestion - 1) / test.totalQuestions) * 100 : 0
  const currentQuestionData = getCurrentQuestionData()
  const currentAnswer = currentQuestionData ? answers[currentQuestionData.id] : undefined
  const canProceed = currentAnswer !== undefined

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <Brain className="h-16 w-16 text-blue-500 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Test yükleniyor...</p>
        </div>
      </div>
    )
  }

  if (!test) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-16 w-16 text-red-500 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">Test bulunamadı</p>
          <Link href="/">
            <Button>Ana Sayfaya Dön</Button>
          </Link>
        </div>
      </div>
    )
  }

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
          className="w-full max-w-2xl"
        >
          <Card className="bg-white/80 backdrop-blur-md border-0 shadow-xl">
            <CardHeader className="text-center">
              <CheckCircle className="h-20 w-20 text-green-500 mx-auto mb-4" />
              <CardTitle className="text-2xl text-green-600">Test Tamamlandı!</CardTitle>
              <CardDescription>
                {test?.testName} testini başarıyla tamamladınız
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Test Sonuçlarınız</h3>
                <p className="text-gray-600">Toplam Puan: <span className="font-bold">{calculateTotalScore()}</span></p>
                <p className="text-gray-600">Cevaplanan Soru: <span className="font-bold">{Object.keys(answers).length}</span></p>
              </div>
              
              <div className="space-y-3">
                <Button
                  onClick={async () => {
                    try {
                      const response = await fetch(`/api/test-results/${testResult?.id}/email`, {
                        method: 'POST',
                      })
                      if (response.ok) {
                        toast({
                          title: 'Başarılı!',
                          description: 'Test sonuçları e-posta adresinize gönderildi',
                        })
                      }
                    } catch (error) {
                      toast({
                        title: 'Hata',
                        description: 'E-posta gönderilemedi',
                        variant: 'destructive',
                      })
                    }
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Sonuçları E-posta ile Gönder
                </Button>
                
                <Link href="/profile" className="block">
                  <Button variant="outline" className="w-full">
                    Profilde Görüntüle
                  </Button>
                </Link>
                
                <Link href="/" className="block">
                  <Button variant="ghost" className="w-full">
                    <Home className="h-4 w-4 mr-2" />
                    Ana Sayfaya Dön
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    )
  }

  if (showInstructions) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto py-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Card className="bg-white/80 backdrop-blur-md border-0 shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Link href="/">
                    <Button variant="ghost" size="sm">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Ana Sayfa
                    </Button>
                  </Link>
                </div>
                <CardTitle className="text-3xl text-center text-gray-900">
                  {test?.testName}
                </CardTitle>
                <CardDescription className="text-center text-lg">
                  {test?.description}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {test?.instructions && (
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-3">Test Yönergeleri</h3>
                    <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                      {test.instructions}
                    </p>
                  </div>
                )}
                
                <div className="grid md:grid-cols-3 gap-4 text-center">
                  <div className="bg-white p-4 rounded-lg border">
                    <p className="text-2xl font-bold text-blue-600">{test?.totalQuestions || 0}</p>
                    <p className="text-gray-600">Toplam Soru</p>
                  </div>
                  {test?.timeFrame && (
                    <div className="bg-white p-4 rounded-lg border">
                      <p className="text-lg font-bold text-green-600">{test.timeFrame}</p>
                      <p className="text-gray-600">Değerlendirme Dönemi</p>
                    </div>
                  )}
                  <div className="bg-white p-4 rounded-lg border">
                    <p className="text-lg font-bold text-purple-600">Otomatik Kayıt</p>
                    <p className="text-gray-600">İlerleme Korunur</p>
                  </div>
                </div>
                
                <div className="text-center">
                  <Button
                    onClick={() => setShowInstructions(false)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
                  >
                    Teste Başla
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Ana Sayfa
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold text-gray-900">{test?.testName}</h1>
              <p className="text-gray-600">
                Soru {currentQuestion} / {test?.totalQuestions || 0}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              onClick={saveProgress}
              variant="outline"
              size="sm"
              disabled={saving}
            >
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'Kaydediliyor...' : 'Kaydet'}
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" size="sm">
                  Çıkış
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Testten çıkmak istediğinize emin misiniz?</AlertDialogTitle>
                  <AlertDialogDescription>
                    İlerlemeniz otomatik olarak kaydedilecek ve daha sonra kaldığınız yerden devam edebileceksiniz.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>İptal</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={async () => {
                      await saveProgress()
                      router.push('/')
                    }}
                  >
                    Çıkış Yap
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <Progress value={progressPercentage} className="h-3" />
          <p className="text-center text-sm text-gray-600 mt-2">
            %{Math.round(progressPercentage)} tamamlandı
          </p>
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card className="bg-white/80 backdrop-blur-md border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="text-xl text-gray-900">
                  {currentQuestionData?.text || 'Soru bulunamadı'}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {currentQuestionData?.options && (
                  <RadioGroup
                    value={currentAnswer?.toString?.() || ''}
                    onValueChange={(value) => {
                      const numValue = isNaN(Number(value)) ? value : Number(value)
                      handleAnswer(currentQuestionData.id, numValue)
                    }}
                    className="space-y-4"
                  >
                    {currentQuestionData.options.map((option, index) => (
                      <div key={index} className="flex items-center space-x-3 p-3 border rounded-lg hover:bg-blue-50 transition-colors">
                        <RadioGroupItem value={option?.value?.toString?.() || ''} id={`option-${index}`} />
                        <Label 
                          htmlFor={`option-${index}`} 
                          className="flex-1 cursor-pointer text-gray-700"
                        >
                          {option?.label || 'Seçenek bulunamadı'}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <Button
            onClick={prevQuestion}
            variant="outline"
            disabled={currentQuestion === 1}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Önceki
          </Button>

          <span className="text-gray-600">
            {currentQuestion} / {test?.totalQuestions || 0}
          </span>

          <Button
            onClick={nextQuestion}
            disabled={!canProceed || saving}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {currentQuestion === test?.totalQuestions ? 'Testi Tamamla' : 'Sonraki'}
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  )
}

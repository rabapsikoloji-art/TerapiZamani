
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth-options'
import { redirect } from 'next/navigation'
import TestClient from './test-client'

interface Props {
  params: {
    testCode: string
  }
}

export default async function TestPage({ params }: Props) {
  const session = await getServerSession(authOptions)
  
  if (!session) {
    redirect('/auth/login')
  }

  return <TestClient testCode={params?.testCode || ''} />
}


import { PrismaClient } from '@prisma/client'
import { hash } from 'bcryptjs'
import fs from 'fs'
import path from 'path'

const prisma = new PrismaClient()

async function main() {
  console.log('Seeding database...')

  // Test kullanıcısı oluştur (admin privileges ile)
  const hashedPassword = await hash('johndoe123', 10)
  const testUser = await prisma.user.upsert({
    where: { email: 'john@doe.com' },
    update: {},
    create: {
      email: 'john@doe.com',
      password: hashedPassword,
      firstName: 'John',
      lastName: 'Doe',
      name: 'John Doe',
    },
  })

  console.log(`Test user created: ${testUser.email}`)

  // Test verilerini yükle
  const dataDir = path.join(process.cwd(), 'data')
  
  // MMPI test verilerini yükle
  const mmpiData = JSON.parse(fs.readFileSync(path.join(dataDir, 'mmpi_test.json'), 'utf-8'))
  const mmpiTest = await prisma.test.upsert({
    where: { testCode: 'MMPI' },
    update: {
      testName: mmpiData.testName,
      version: mmpiData.version,
      description: mmpiData.description,
      totalQuestions: mmpiData.totalQuestions,
      questions: mmpiData.questions,
      scales: mmpiData.scales || {},
      scoring: mmpiData.scoring || {},
    },
    create: {
      testCode: 'MMPI',
      testName: mmpiData.testName,
      version: mmpiData.version,
      description: mmpiData.description,
      totalQuestions: mmpiData.totalQuestions,
      questions: mmpiData.questions,
      scales: mmpiData.scales || {},
      scoring: mmpiData.scoring || {},
    },
  })

  console.log(`MMPI test loaded: ${mmpiTest.testName}`)

  // SCL-90 test verilerini yükle
  const scl90Data = JSON.parse(fs.readFileSync(path.join(dataDir, 'scl90_test.json'), 'utf-8'))
  const scl90Test = await prisma.test.upsert({
    where: { testCode: 'SCL-90-R' },
    update: {
      testName: scl90Data.testName,
      version: scl90Data.version,
      description: scl90Data.description,
      totalQuestions: scl90Data.totalQuestions,
      questions: scl90Data.questions,
      scales: scl90Data.scales || {},
      scoring: scl90Data.scoring || {},
    },
    create: {
      testCode: 'SCL-90-R',
      testName: scl90Data.testName,
      version: scl90Data.version,
      description: scl90Data.description,
      totalQuestions: scl90Data.totalQuestions,
      questions: scl90Data.questions,
      scales: scl90Data.scales || {},
      scoring: scl90Data.scoring || {},
    },
  })

  console.log(`SCL-90 test loaded: ${scl90Test.testName}`)

  // Otomatik Düşünceler test verilerini yükle
  const odoData = JSON.parse(fs.readFileSync(path.join(dataDir, 'otomatik_dusunceler_test.json'), 'utf-8'))
  const odoTest = await prisma.test.upsert({
    where: { testCode: 'ODO' },
    update: {
      testName: odoData.testName,
      version: odoData.version,
      description: odoData.description,
      totalQuestions: odoData.totalQuestions,
      instructions: odoData.instructions,
      timeFrame: odoData.timeFrame,
      questions: odoData.questions,
      scales: odoData.scales || {},
      scoring: odoData.scoring || {},
    },
    create: {
      testCode: 'ODO',
      testName: odoData.testName,
      version: odoData.version,
      description: odoData.description,
      totalQuestions: odoData.totalQuestions,
      instructions: odoData.instructions,
      timeFrame: odoData.timeFrame,
      questions: odoData.questions,
      scales: odoData.scales || {},
      scoring: odoData.scoring || {},
    },
  })

  console.log(`ODO test loaded: ${odoTest.testName}`)

  console.log('Seeding completed!')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (e) => {
    console.error(e)
    await prisma.$disconnect()
    process.exit(1)
  })

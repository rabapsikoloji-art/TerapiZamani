# MMPI FULL WORK hesaplama, tablo, grafik, exel upload ve download çalışıyor :)

A Pen created on CodePen.

Original URL: [https://codepen.io/Rafi9999/pen/dyBwRWe](https://codepen.io/Rafi9999/pen/dyBwRWe).

